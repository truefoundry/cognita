
# [Hdfc bank upi rupay credit card](https://www.hdfcbank.com/personal/pay/cards/credit-cards/hdfc-bank-upi-rupay-credit-card)

## Features
#### Key Features:
Key Features:
* 3% Cashpoints on Groceries, SuperMarket & Dining spends & PayZapp transactions. (Maximum of 500 Points can be earned in a calendar month)
* 2% Cashpoints on Utility spends (Maximum of 500 Points can be earned in a calendar month)
* 1% Cashpoints on other spends (Excluding Rent, Wallet loads, EMI, Fuel, Insurance Payments & Government categories) (Maximum of 500 Points can be earned in a calendar month)
**Note:** The above benefits are applicable for both UPI as well as regular credit card spends.
For detailed Terms & conditions [Click here](/Personal/Pay/Cards/Credit Card/Credit Card Landing Page/Credit Cards/HDFC Bank UPI RuPay Credit Card/Terms-and-Conditions-HDFC-Bank-UPI-RuPay-Credit-Card-03042023.pdf "/Personal/Pay/Cards/Credit Card/Credit Card Landing Page/Credit Cards/HDFC Bank UPI RuPay Credit Card/Terms-and-Conditions-HDFC-Bank-UPI-RuPay-Credit-Card-03042023.pdf")
#### Important Information
Important Information
Credit Card PIN set up is a pre-requisite for UPI registration. You can easily set your Credit Card PIN by calling 1860 266 0333
**Steps to Link HDFC Bank RuPay UPI Credit Card in UPI Apps:**
* Download & Register / Open your UPI app (PayZapp/ GPay/ PhonePe/ Mobikwik/ PayTM/ BHIM/ Slice)
* Register HDFC Bank UPI RuPay Credit Card by using credit card PIN.
* Make UPI Payments using credit cards & Enjoy credit card benefits​​​​​​​
#### Interest Free Credit Period
Interest Free Credit Period
​​​​​Avail up to 50 days of interest free period on your HDFC Bank UPI RuPay Credit Card from the date of purchase (subject to the submission of the charge by the Merchant).
#### Revolving Credit
Revolving Credit
Enjoy Revolving Credit on your HDFC Bank UPI RuPay Credit Card at nominal interest rate. Please refer to the Fees and Charges section for more details.
#### Renewal offer
Renewal offer
Get renewal membership fee waived off by spending ₹25,000 and above in an annual year
#### Reward Point/Cashback Redemption & Validity
Reward Point/Cashback Redemption & Validity
* The CashPoints earned on HDFC Bank UPI RuPay Credit Card can be redeemed against the statement balance at the rate of 1 CashPoint = ₹0.25, and can be done via Net Banking login, or physical redemption form
* CashPoints can also be used for redemption against travel benefits like Flight & Hotel bookings and also on Rewards Catalogue at the SmartBuy Rewards Portal, wherein Credit Card members can redeem up to a maximum of 50% of the booking value through CashPoints at a value of 1 CashPoint = ₹0.25 and the rest of the amount will have to be paid via the Credit Card. To know more on Rewards catalouge, [click here](/personal/pay/cards/credit-cards/claim-rewards "/personal/pay/cards/credit-cards/claim-rewards")
* With effect from 1st January 2023, Reward points redemption for flights & hotels bookings are capped per calendar month at 50,000.
* With effect from 1st February 2023, Reward points redemption for CashBack redemption are capped per calendar month to 50,000 rewards points.
* With effect from 1st February 2023, cardmembers can redeem upto 70% of product/Voucher value through Reward points on select vouchers/products and pay the remaining amount via Credit card.
* For redemption against statement balance, Cardholder must have minimum CashPoints equivalent to ₹500
* CashPoints earned on your HDFC Bank UPI RuPay Credit Card are valid only for 2 years from the date of transaction. e.g. if you receive Reward Points in August 2021, same will expire in August 2023
|  |
| --- |
| **Value per Point (in Rs)** |
| **Product Catalogue** | **Unified SmartBuy (Flights/Hotels)** | **Cash back** | **Airmiles** |
| 0.25 | 0.25 | 0.25 | 0.25 |
To Know more about UPI purchases on Credit card, [click here](/personal/rupay-cc-on-upi "/personal/rupay-cc-on-upi")
[FAQs](/Personal/Pay/Cards/Credit Card/Credit Card Landing Page/Credit Cards/HDFC Bank UPI RuPay Credit Card/RuPay-UPI-Credit-Card-FAQs.pdf)



## Fees and Charges
Joining/ Renewal Membership Fee - ₹99/- + Applicable Taxes (Festive Season Offer!!!)
Spend ₹25,000 or more in an annual year, before your Credit Card renewal date and get your renewal fee waived off from 2nd year onwards
[Click here](/Personal/Pay/Cards/Credit Card/Credit Card Landing Page/Manage Your Credit Cards PDFs/MITC 1.64.pdf "/Personal/Pay/Cards/Credit Card/Credit Card Landing Page/Manage Your Credit Cards PDFs/MITC 1.64.pdf") to view details of HDFC Bank UPI RuPay Credit Card Fees and Charges.
